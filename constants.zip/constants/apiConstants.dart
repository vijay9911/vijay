const String apiBaseUrl = 'http://hyperstorz.anxion.co.in/api/';
const String SEND_OTP = 'user/send-otp';
const String VERIFY_OTP = 'manager/verify-otp';
const String CHECK_API = 'user/check?auth_code=';
const String SIGNUP_FORM = 'manager/signup';